# RankingAPI


This project no longer works: 


Today at 18:17 BST all users with email subscriptions for Heroku were sent an email that will effect **A LOT** of systems.


# Message
***

Dear Customer,

Thank you for being a Heroku user. Starting November 28, 2022, free Heroku Dynos, free Heroku Postgres, and free Heroku Data for Redis® will no longer be available. You can learn more about these and other important changes from our GM, Bob Wise, on the [Heroku blog](https://hello.heroku.com/e/36622/next-chapter/m49jd1/1138388508?h=8QR7PGcfRUlgyMu84mgy4FTdMFqyuvPv54Xm2sY4Lw8).

Existing free dynos and Heroku data add-ons will be impacted, so action by you is required. To prevent any disruption to your apps or data using free plans, you will need to upgrade from a free plan to a paid plan before November 28, 2022.

For instructions on how to upgrade and for other questions, please [visit our FAQ](https://hello.heroku.com/e/36622/-heroku-free-product-plans-faq/m49jd4/1138388508?h=8QR7PGcfRUlgyMu84mgy4FTdMFqyuvPv54Xm2sY4Lw8).

Thank you,

The Heroku Team


# What should I do now?  
***

If your willing to pay for dynos, go ahead, it will still work perfectly.  Starting **November 28, 2022** all , free Heroku Dynos, free Heroku Postgres, and free Heroku Data for Redis® will no longer be available. Meaning the project will not work 
unless you pay.

A free alternative you could consider using is [Rankgun](https://www.rankgun.works/)
